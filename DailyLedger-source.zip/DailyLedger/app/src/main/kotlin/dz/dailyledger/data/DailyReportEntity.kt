package dz.dailyledger.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

@Entity(tableName = "daily_reports")
data class DailyReportEntity(
    /** LocalDate.toEpochDay(), stable across time zones. */
    @PrimaryKey val dateEpochDay: Long,
    val g1Dzd: Long,
    val g2Dzd: Long,
    val startingFloatDzd: Long,
    val j1Dzd: Long,
    val j2Dzd: Long,
    val actualCashDzd: Long,
    val supplierTotalDzd: Long,
    val theoreticalFinalDzd: Long,
    val actualFinalDzd: Long,
    val varianceDzd: Long,
    val notes: String,
    val savedAtEpochMillis: Long,
)

@Entity(
    tableName = "supplier_payments",
    foreignKeys = [
        ForeignKey(
            entity = DailyReportEntity::class,
            parentColumns = ["dateEpochDay"],
            childColumns = ["reportDateEpochDay"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["reportDateEpochDay", "position"], unique = true)],
)
data class SupplierPaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reportDateEpochDay: Long,
    val position: Int,
    val amountDzd: Long,
)

data class DailyReportWithSuppliers(
    @androidx.room.Embedded val report: DailyReportEntity,
    @Relation(
        parentColumn = "dateEpochDay",
        entityColumn = "reportDateEpochDay",
    )
    val suppliers: List<SupplierPaymentEntity>,
)
