package dz.dailyledger.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory

@Database(
    entities = [DailyReportEntity::class, SupplierPaymentEntity::class],
    version = 1,
    exportSchema = true,
)
abstract class DailyLedgerDatabase : RoomDatabase() {
    abstract fun dailyReportDao(): DailyReportDao

    companion object {
        fun create(context: Context): DailyLedgerDatabase {
            System.loadLibrary("sqlcipher")
            val passphrase = DatabasePassphraseStore(context).getPassphrase()
            val helperFactory = SupportOpenHelperFactory(passphrase)
            return Room.databaseBuilder(
                context.applicationContext,
                DailyLedgerDatabase::class.java,
                "daily-ledger.db",
            )
                .openHelperFactory(helperFactory)
                .build()
        }
    }
}
