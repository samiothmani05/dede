package dz.dailyledger.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import dz.dailyledger.data.DailyReportRepository
import dz.dailyledger.data.DailyReportWithSuppliers
import dz.dailyledger.domain.DailyCalculation
import dz.dailyledger.domain.DailyCalculator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate

data class SupplierDraft(val key: Long, val amount: String = "")

data class DailyFormState(
    val date: LocalDate = LocalDate.now(),
    val g1: String = "",
    val g2: String = "",
    val j1: String = "",
    val j2: String = "",
    val actualCash: String = "",
    val notes: String = "",
    val suppliers: List<SupplierDraft> = listOf(SupplierDraft(1)),
    val saving: Boolean = false,
    val saved: Boolean = false,
    val error: FormError? = null,
    val saveFailed: Boolean = false,
)

sealed interface FormError {
    data class Required(val field: String) : FormError
    data class Invalid(val field: String) : FormError
    data object TooLarge : FormError
}

private data class ParsedForm(
    val g1: Long,
    val g2: Long,
    val j1: Long,
    val j2: Long,
    val cash: Long,
    val suppliers: List<Long>,
    val calculation: DailyCalculation,
)

class LedgerViewModel(private val repository: DailyReportRepository) : ViewModel() {
    private val mutableForm = MutableStateFlow(DailyFormState())
    val form: StateFlow<DailyFormState> = mutableForm.asStateFlow()
    val history: StateFlow<List<DailyReportWithSuppliers>> = repository.history.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptyList(),
    )

    private var nextSupplierKey = 2L

    init {
        loadToday()
    }

    fun setG1(value: String) = edit { copy(g1 = value) }
    fun setG2(value: String) = edit { copy(g2 = value) }
    fun setJ1(value: String) = edit { copy(j1 = value) }
    fun setJ2(value: String) = edit { copy(j2 = value) }
    fun setCash(value: String) = edit { copy(actualCash = value) }
    fun setNotes(value: String) = edit { copy(notes = value) }

    fun setSupplier(key: Long, value: String) = edit {
        copy(suppliers = suppliers.map { if (it.key == key) it.copy(amount = value) else it })
    }

    fun addSupplier() = edit {
        copy(suppliers = suppliers + SupplierDraft(nextSupplierKey++))
    }

    fun removeSupplier(key: Long) = edit {
        if (suppliers.size <= 1) this else copy(suppliers = suppliers.filterNot { it.key == key })
    }

    fun calculationPreview(): DailyCalculation? = when (val parsed = parse(mutableForm.value)) {
        is ParseResult.Valid -> parsed.value.calculation
        is ParseResult.Invalid -> null
    }

    fun refreshForCurrentDate() {
        val today = LocalDate.now()
        if (today == mutableForm.value.date) return
        mutableForm.value = DailyFormState(date = today)
        nextSupplierKey = 2L
        loadToday()
    }

    fun save() {
        val current = mutableForm.value
        if (current.saving) return
        when (val parsed = parse(current)) {
            is ParseResult.Invalid -> mutableForm.update { it.copy(error = parsed.error, saved = false) }
            is ParseResult.Valid -> {
                mutableForm.update { it.copy(error = null, saveFailed = false, saving = true, saved = false) }
                viewModelScope.launch {
                    runCatching {
                        val values = parsed.value
                        repository.save(
                            date = current.date,
                            g1 = values.g1,
                            g2 = values.g2,
                            startingFloat = DailyCalculator.DEFAULT_FLOAT_DZD,
                            j1 = values.j1,
                            j2 = values.j2,
                            actualCash = values.cash,
                            notes = current.notes,
                            supplierAmounts = values.suppliers,
                            supplierTotal = values.calculation.supplierTotal,
                            theoreticalFinal = values.calculation.theoreticalFinal,
                            actualFinal = values.calculation.actualFinal,
                            variance = values.calculation.variance,
                            savedAtEpochMillis = System.currentTimeMillis(),
                        )
                    }.onSuccess {
                        mutableForm.update { it.copy(saving = false, saved = true) }
                    }.onFailure {
                        mutableForm.update { it.copy(saving = false, saveFailed = true) }
                    }
                }
            }
        }
    }

    private fun loadToday() {
        viewModelScope.launch {
            runCatching { repository.find(mutableForm.value.date) }
                .getOrNull()
                ?.let { saved ->
                    val report = saved.report
                    mutableForm.value = DailyFormState(
                        date = LocalDate.ofEpochDay(report.dateEpochDay),
                        g1 = report.g1Dzd.toString(),
                        g2 = report.g2Dzd.toString(),
                        j1 = report.j1Dzd.toString(),
                        j2 = report.j2Dzd.toString(),
                        actualCash = report.actualCashDzd.toString(),
                        notes = report.notes,
                        suppliers = saved.suppliers.sortedBy { it.position }.mapIndexed { index, row ->
                            SupplierDraft(index.toLong() + 1, row.amountDzd.toString())
                        }.ifEmpty { listOf(SupplierDraft(1)) },
                    )
                    nextSupplierKey = mutableForm.value.suppliers.maxOfOrNull { it.key }?.plus(1) ?: 1
                }
        }
    }

    private inline fun edit(crossinline change: DailyFormState.() -> DailyFormState) {
        mutableForm.update { change(it).copy(saved = false, error = null, saveFailed = false) }
    }

    private fun parse(form: DailyFormState): ParseResult {
        val g1 = form.g1.parseAmount(required = true) ?: return ParseResult.Invalid(form.g1.toFieldError("G1", true))
        val g2 = form.g2.parseAmount(required = true) ?: return ParseResult.Invalid(form.g2.toFieldError("G2", true))
        val j1 = form.j1.parseAmount(required = false) ?: return ParseResult.Invalid(form.j1.toFieldError("J1", false))
        val j2 = form.j2.parseAmount(required = false) ?: return ParseResult.Invalid(form.j2.toFieldError("J2", false))
        val cash = form.actualCash.parseAmount(required = true) ?: return ParseResult.Invalid(form.actualCash.toFieldError("C", true))
        val suppliers = mutableListOf<Long>()
        for (draft in form.suppliers) {
            val amount = draft.amount.parseAmount(required = false)
                ?: return ParseResult.Invalid(draft.amount.toFieldError("LV", false))
            suppliers += amount
        }
        return try {
            ParseResult.Valid(
                ParsedForm(
                    g1 = g1,
                    g2 = g2,
                    j1 = j1,
                    j2 = j2,
                    cash = cash,
                    suppliers = suppliers,
                    calculation = DailyCalculator.calculate(g1, g2, j1, j2, suppliers, cash),
                ),
            )
        } catch (_: ArithmeticException) {
            ParseResult.Invalid(FormError.TooLarge)
        }
    }

    private fun String.parseAmount(required: Boolean): Long? {
        val normalized = normalizeDigits(this).filterNot { it.isWhitespace() || it == ',' || it == '٬' }
        if (normalized.isEmpty()) return if (required) null else 0L
        val amount = normalized.toLongOrNull() ?: return null
        return amount.takeIf { it >= 0 }
    }

    private fun String.toFieldError(field: String, required: Boolean): FormError =
        if (trim().isEmpty() && required) FormError.Required(field) else FormError.Invalid(field)

    private fun normalizeDigits(value: String): String = buildString(value.length) {
        value.forEach { char ->
            when (char) {
                in '\u0660'..'\u0669' -> append(('0'.code + char.code - '\u0660'.code).toChar())
                in '\u06F0'..'\u06F9' -> append(('0'.code + char.code - '\u06F0'.code).toChar())
                else -> append(char)
            }
        }
    }

    private sealed interface ParseResult {
        data class Valid(val value: ParsedForm) : ParseResult
        data class Invalid(val error: FormError) : ParseResult
    }
}

class LedgerViewModelFactory(private val repository: DailyReportRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        require(modelClass.isAssignableFrom(LedgerViewModel::class.java))
        return LedgerViewModel(repository) as T
    }
}
