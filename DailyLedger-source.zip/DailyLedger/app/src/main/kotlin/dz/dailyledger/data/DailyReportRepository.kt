package dz.dailyledger.data

import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

class DailyReportRepository(database: DailyLedgerDatabase) {
    private val dao = database.dailyReportDao()

    val history: Flow<List<DailyReportWithSuppliers>> = dao.observeAll()

    suspend fun find(date: LocalDate): DailyReportWithSuppliers? = dao.findByDay(date.toEpochDay())

    suspend fun save(
        date: LocalDate,
        g1: Long,
        g2: Long,
        startingFloat: Long,
        j1: Long,
        j2: Long,
        actualCash: Long,
        notes: String,
        supplierAmounts: List<Long>,
        supplierTotal: Long,
        theoreticalFinal: Long,
        actualFinal: Long,
        variance: Long,
        savedAtEpochMillis: Long,
    ) {
        val day = date.toEpochDay()
        dao.save(
            report = DailyReportEntity(
                dateEpochDay = day,
                g1Dzd = g1,
                g2Dzd = g2,
                startingFloatDzd = startingFloat,
                j1Dzd = j1,
                j2Dzd = j2,
                actualCashDzd = actualCash,
                supplierTotalDzd = supplierTotal,
                theoreticalFinalDzd = theoreticalFinal,
                actualFinalDzd = actualFinal,
                varianceDzd = variance,
                notes = notes,
                savedAtEpochMillis = savedAtEpochMillis,
            ),
            suppliers = supplierAmounts.mapIndexed { index, amount ->
                SupplierPaymentEntity(
                    reportDateEpochDay = day,
                    position = index,
                    amountDzd = amount,
                )
            },
        )
    }
}
