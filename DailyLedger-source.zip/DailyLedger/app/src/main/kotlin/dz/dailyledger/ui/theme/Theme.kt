package dz.dailyledger.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Green = Color(0xFF176B52)
private val DeepGreen = Color(0xFF123F34)
private val Surface = Color(0xFFF5F7F4)
private val Error = Color(0xFFB3261E)

@Composable
fun DailyLedgerTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) {
        darkColorScheme(primary = Color(0xFF82D6B6), secondary = Color(0xFFB5DCCB), error = Color(0xFFFFB4AB))
    } else {
        lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            secondary = DeepGreen,
            background = Surface,
            surface = Color.White,
            error = Error,
        )
    }
    MaterialTheme(colorScheme = colors, content = content)
}
