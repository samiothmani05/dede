package dz.dailyledger.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
abstract class DailyReportDao {
    @Transaction
    @Query("SELECT * FROM daily_reports ORDER BY dateEpochDay DESC")
    abstract fun observeAll(): Flow<List<DailyReportWithSuppliers>>

    @Transaction
    @Query("SELECT * FROM daily_reports WHERE dateEpochDay = :day LIMIT 1")
    abstract suspend fun findByDay(day: Long): DailyReportWithSuppliers?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    protected abstract suspend fun insertReport(report: DailyReportEntity)

    @Query("DELETE FROM supplier_payments WHERE reportDateEpochDay = :day")
    protected abstract suspend fun deleteSuppliers(day: Long)

    @Insert
    protected abstract suspend fun insertSuppliers(payments: List<SupplierPaymentEntity>)

    @Transaction
    open suspend fun save(report: DailyReportEntity, suppliers: List<SupplierPaymentEntity>) {
        insertReport(report)
        deleteSuppliers(report.dateEpochDay)
        if (suppliers.isNotEmpty()) insertSuppliers(suppliers)
    }
}
