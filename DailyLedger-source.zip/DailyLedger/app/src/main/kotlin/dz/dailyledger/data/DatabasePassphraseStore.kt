package dz.dailyledger.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec

/** Stores a random SQLCipher key encrypted by a non-exportable Android Keystore AES key. */
internal class DatabasePassphraseStore(context: Context) {
    private val preferences = context.getSharedPreferences("database_key", Context.MODE_PRIVATE)
    private val random = SecureRandom()

    @Synchronized
    fun getPassphrase(): ByteArray {
        val saved = preferences.getString(KEY_CIPHERTEXT, null)
        if (saved != null) return decrypt(Base64.decode(saved, Base64.NO_WRAP))

        val rawKey = ByteArray(32).also(random::nextBytes)
        val phrase = rawKey.joinToString(separator = "") { "%02x".format(it.toInt() and 0xFF) }
            .toByteArray(Charsets.US_ASCII)
        rawKey.fill(0)

        val encrypted = encrypt(phrase)
        check(preferences.edit().putString(KEY_CIPHERTEXT, Base64.encodeToString(encrypted, Base64.NO_WRAP)).commit()) {
            "Unable to persist the encrypted database key"
        }
        return phrase
    }

    private fun encrypt(plain: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateWrappingKey())
        val encrypted = cipher.doFinal(plain)
        return cipher.iv + encrypted
    }

    private fun decrypt(blob: ByteArray): ByteArray {
        require(blob.size > GCM_IV_SIZE) { "Invalid encrypted database key" }
        val iv = blob.copyOfRange(0, GCM_IV_SIZE)
        val ciphertext = blob.copyOfRange(GCM_IV_SIZE, blob.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateWrappingKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(ciphertext)
    }

    private fun getOrCreateWrappingKey(): java.security.Key {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        keyStore.getKey(KEY_ALIAS, null)?.let { return it }

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build(),
        )
        return generator.generateKey()
    }

    private companion object {
        const val KEY_ALIAS = "daily-ledger-db-wrap-v1"
        const val KEY_CIPHERTEXT = "wrapped_sqlcipher_key"
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val GCM_IV_SIZE = 12
    }
}
