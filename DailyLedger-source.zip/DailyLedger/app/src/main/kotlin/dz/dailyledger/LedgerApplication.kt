package dz.dailyledger

import android.app.Application
import dz.dailyledger.data.DailyLedgerDatabase
import dz.dailyledger.data.DailyReportRepository

class LedgerApplication : Application() {
    lateinit var repository: DailyReportRepository
        private set

    override fun onCreate() {
        super.onCreate()
        repository = DailyReportRepository(
            DailyLedgerDatabase.create(this),
        )
    }
}
