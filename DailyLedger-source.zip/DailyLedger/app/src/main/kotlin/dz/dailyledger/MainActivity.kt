package dz.dailyledger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import dz.dailyledger.ui.LedgerApp
import dz.dailyledger.ui.LedgerViewModel
import dz.dailyledger.ui.LedgerViewModelFactory
import dz.dailyledger.ui.theme.DailyLedgerTheme

class MainActivity : ComponentActivity() {
    private val viewModel: LedgerViewModel by viewModels {
        LedgerViewModelFactory((application as LedgerApplication).repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DailyLedgerTheme {
                LedgerApp(viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshForCurrentDate()
    }
}
