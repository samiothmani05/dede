package dz.dailyledger.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dz.dailyledger.R
import dz.dailyledger.data.DailyReportWithSuppliers
import dz.dailyledger.domain.DailyCalculation
import dz.dailyledger.domain.DailyCalculator
import java.text.NumberFormat
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

private enum class MainTab { TODAY, HISTORY }

@Composable
fun LedgerApp(viewModel: LedgerViewModel) {
    val form by viewModel.form.collectAsStateWithLifecycle()
    val reports by viewModel.history.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableStateOf(MainTab.TODAY) }
    var selectedReport by remember { mutableStateOf<DailyReportWithSuppliers?>(null) }

    BackHandler(enabled = selectedReport != null) { selectedReport = null }

    Scaffold(
        bottomBar = {
            if (selectedReport == null) {
                NavigationBar {
                    NavigationBarItem(
                        selected = tab == MainTab.TODAY,
                        onClick = { tab = MainTab.TODAY },
                        icon = { Icon(Icons.Default.Calculate, contentDescription = null) },
                        label = { Text(stringResource(R.string.daily_tab)) },
                    )
                    NavigationBarItem(
                        selected = tab == MainTab.HISTORY,
                        onClick = { tab = MainTab.HISTORY },
                        icon = { Icon(Icons.Default.History, contentDescription = null) },
                        label = { Text(stringResource(R.string.history_tab)) },
                    )
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { scaffoldPadding ->
        when {
            selectedReport != null -> ReportDetailScreen(
                report = selectedReport!!,
                contentPadding = scaffoldPadding,
                onBack = { selectedReport = null },
            )
            tab == MainTab.TODAY -> DailyEntryScreen(
                form = form,
                preview = viewModel.calculationPreview(),
                contentPadding = scaffoldPadding,
                onG1 = viewModel::setG1,
                onG2 = viewModel::setG2,
                onJ1 = viewModel::setJ1,
                onJ2 = viewModel::setJ2,
                onCash = viewModel::setCash,
                onNotes = viewModel::setNotes,
                onSupplier = viewModel::setSupplier,
                onAddSupplier = viewModel::addSupplier,
                onRemoveSupplier = viewModel::removeSupplier,
                onSave = viewModel::save,
            )
            else -> HistoryScreen(
                reports = reports,
                contentPadding = scaffoldPadding,
                onOpen = { selectedReport = it },
            )
        }
    }
}

@Composable
private fun DailyEntryScreen(
    form: DailyFormState,
    preview: DailyCalculation?,
    contentPadding: PaddingValues,
    onG1: (String) -> Unit,
    onG2: (String) -> Unit,
    onJ1: (String) -> Unit,
    onJ2: (String) -> Unit,
    onCash: (String) -> Unit,
    onNotes: (String) -> Unit,
    onSupplier: (Long, String) -> Unit,
    onAddSupplier: () -> Unit,
    onRemoveSupplier: (Long) -> Unit,
    onSave: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        Spacer(Modifier.height(20.dp))
        Text(stringResource(R.string.today_title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            "${formatDate(form.date)} · ${stringResource(R.string.today_subtitle)}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp, bottom = 18.dp),
        )

        SectionTitle(stringResource(R.string.section_revenue))
        MoneyField(stringResource(R.string.g1_label), form.g1, onG1)
        MoneyField(stringResource(R.string.g2_label), form.g2, onG2)
        FixedFloatCard()

        SectionTitle(stringResource(R.string.section_staff))
        MoneyField(stringResource(R.string.j1_label), form.j1, onJ1)
        MoneyField(stringResource(R.string.j2_label), form.j2, onJ2)

        SectionTitle(stringResource(R.string.section_suppliers))
        form.suppliers.forEachIndexed { index, supplier ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                MoneyField(
                    label = stringResource(R.string.supplier_row, index + 1),
                    value = supplier.amount,
                    onValueChange = { onSupplier(supplier.key, it) },
                    modifier = Modifier.weight(1f),
                )
                IconButton(
                    onClick = { onRemoveSupplier(supplier.key) },
                    enabled = form.suppliers.size > 1,
                    modifier = Modifier.size(48.dp),
                ) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = stringResource(R.string.remove_supplier, index + 1),
                        tint = if (form.suppliers.size > 1) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        Button(onClick = onAddSupplier, modifier = Modifier.padding(top = 6.dp)) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text(stringResource(R.string.add_supplier))
        }

        SectionTitle(stringResource(R.string.section_count))
        MoneyField(stringResource(R.string.c_label), form.actualCash, onCash)

        SectionTitle(stringResource(R.string.section_notes))
        OutlinedTextField(
            value = form.notes,
            onValueChange = onNotes,
            label = { Text(stringResource(R.string.notes_hint)) },
            minLines = 3,
            modifier = Modifier.fillMaxWidth(),
        )

        SectionTitle(stringResource(R.string.results_title))
        ResultsCard(preview)

        form.error?.let { error ->
            Text(
                text = errorMessage(error),
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 12.dp),
            )
        }
        if (form.saved) {
            Text(
                stringResource(R.string.save_success),
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 12.dp),
            )
        } else if (form.saveFailed) {
            Text(
                stringResource(R.string.save_error),
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(top = 12.dp),
            )
        }

        Button(
            onClick = onSave,
            enabled = !form.saving,
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 24.dp).height(54.dp),
        ) {
            if (form.saving) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                Spacer(Modifier.width(10.dp))
            }
            Text(stringResource(if (form.saving) R.string.saving else R.string.save_report))
        }
    }
}

@Composable
private fun MoneyField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        suffix = { Text(stringResource(R.string.dzd), style = MaterialTheme.typography.labelSmall) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier.fillMaxWidth().padding(bottom = 8.dp),
    )
}

@Composable
private fun FixedFloatCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(stringResource(R.string.k_label), modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            Text(displayMoney(DailyCalculator.DEFAULT_FLOAT_DZD), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ResultsCard(calculation: DailyCalculation?) {
    val varianceColor = when {
        calculation == null -> MaterialTheme.colorScheme.onSurface
        calculation.variance == 0L -> Color(0xFF176B52)
        else -> MaterialTheme.colorScheme.error
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            ResultRow(stringResource(R.string.ct_label), calculation?.theoreticalFinal, MaterialTheme.colorScheme.primary)
            ResultRow(stringResource(R.string.cc_label), calculation?.actualFinal, MaterialTheme.colorScheme.secondary)
            Surface(color = varianceColor.copy(alpha = 0.09f), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    ResultRow(stringResource(R.string.variance_label), calculation?.variance, varianceColor)
                    Text(
                        stringResource(R.string.variance_help),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 5.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun ResultRow(label: String, amount: Long?, color: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(amount?.let { displayMoney(it) } ?: "—", fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.secondary,
        modifier = Modifier.padding(top = 22.dp, bottom = 10.dp),
    )
}

@Composable
private fun HistoryScreen(
    reports: List<DailyReportWithSuppliers>,
    contentPadding: PaddingValues,
    onOpen: (DailyReportWithSuppliers) -> Unit,
) {
    Column(Modifier.fillMaxSize().padding(contentPadding)) {
        Column(Modifier.padding(horizontal = 20.dp).padding(top = 20.dp, bottom = 12.dp)) {
            Text(stringResource(R.string.history_title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.history_subtitle), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (reports.isEmpty()) {
            EmptyHistory()
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(reports, key = { it.report.dateEpochDay }) { report ->
                    HistoryReportCard(report, onClick = { onOpen(report) })
                }
            }
        }
    }
}

@Composable
private fun EmptyHistory() {
    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = CircleShape, modifier = Modifier.size(72.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.History, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
            }
        }
        Text(stringResource(R.string.history_empty_title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
        Text(stringResource(R.string.history_empty_body), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun HistoryReportCard(report: DailyReportWithSuppliers, onClick: () -> Unit) {
    val row = report.report
    val varianceColor = if (row.varianceDzd == 0L) Color(0xFF176B52) else MaterialTheme.colorScheme.error
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(formatDate(LocalDate.ofEpochDay(row.dateEpochDay)), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(stringResource(R.string.ct_label), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(displayMoney(row.theoreticalFinalDzd), fontWeight = FontWeight.SemiBold)
            }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(stringResource(R.string.cc_label), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(displayMoney(row.actualFinalDzd), fontWeight = FontWeight.SemiBold)
            }
            Row(Modifier.fillMaxWidth().padding(top = 9.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(stringResource(R.string.variance_label), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(displayMoney(row.varianceDzd), fontWeight = FontWeight.Bold, color = varianceColor)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReportDetailScreen(
    report: DailyReportWithSuppliers,
    contentPadding: PaddingValues,
    onBack: () -> Unit,
) {
    val row = report.report
    Column(Modifier.fillMaxSize().padding(contentPadding)) {
        TopAppBar(
            title = { Text(stringResource(R.string.report_detail)) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = stringResource(R.string.back))
                }
            },
        )
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            Text(formatDate(LocalDate.ofEpochDay(row.dateEpochDay)), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(
                "${stringResource(R.string.saved_at_label)} · ${formatTime(row.savedAtEpochMillis)}",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp),
            )
            DetailCard(stringResource(R.string.inputs_title)) {
                DetailRow(stringResource(R.string.g1_label), row.g1Dzd)
                DetailRow(stringResource(R.string.g2_label), row.g2Dzd)
                DetailRow(stringResource(R.string.k_label), row.startingFloatDzd)
                DetailRow(stringResource(R.string.j1_label), row.j1Dzd)
                DetailRow(stringResource(R.string.j2_label), row.j2Dzd)
                DetailRow(stringResource(R.string.c_label), row.actualCashDzd)
                DetailRow(stringResource(R.string.supplier_total), row.supplierTotalDzd)
                report.suppliers.sortedBy { it.position }.forEachIndexed { index, supplier ->
                    DetailRow(stringResource(R.string.supplier_row, index + 1), supplier.amountDzd)
                }
            }
            DetailCard(stringResource(R.string.results_title)) {
                DetailRow(stringResource(R.string.ct_label), row.theoreticalFinalDzd, emphasized = true)
                DetailRow(stringResource(R.string.cc_label), row.actualFinalDzd, emphasized = true)
                DetailRow(stringResource(R.string.variance_label), row.varianceDzd, emphasized = true)
            }
            DetailCard(stringResource(R.string.section_notes)) {
                Text(
                    row.notes.ifBlank { stringResource(R.string.notes_none) },
                    color = if (row.notes.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun DetailCard(title: String, content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp))
            content()
        }
    }
}

@Composable
private fun DetailRow(label: String, amount: Long, emphasized: Boolean = false) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(displayMoney(amount), fontWeight = if (emphasized) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable
private fun errorMessage(error: FormError): String = when (error) {
    is FormError.Required -> stringResource(R.string.enter_required, fieldLabel(error.field))
    is FormError.Invalid -> stringResource(R.string.invalid_amount, fieldLabel(error.field))
    FormError.TooLarge -> stringResource(R.string.amount_too_large)
}

@Composable
private fun fieldLabel(field: String): String = when (field) {
    "G1" -> stringResource(R.string.g1_label)
    "G2" -> stringResource(R.string.g2_label)
    "J1" -> stringResource(R.string.j1_label)
    "J2" -> stringResource(R.string.j2_label)
    "C" -> stringResource(R.string.c_label)
    else -> stringResource(R.string.section_suppliers)
}

private fun formatMoney(amount: Long): String {
    val formatter = NumberFormat.getIntegerInstance(Locale.getDefault())
    return formatter.format(amount)
}

@Composable
private fun displayMoney(amount: Long): String = "${formatMoney(amount)} ${stringResource(R.string.dzd)}"

@Composable
private fun formatDate(date: LocalDate): String {
    val locale = Locale.getDefault()
    return remember(date, locale) {
        DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL).withLocale(locale).format(date)
    }
}

private fun formatTime(epochMillis: Long): String = DateTimeFormatter.ofPattern("HH:mm:ss", Locale.getDefault())
    .withZone(ZoneId.systemDefault())
    .format(Instant.ofEpochMilli(epochMillis))
