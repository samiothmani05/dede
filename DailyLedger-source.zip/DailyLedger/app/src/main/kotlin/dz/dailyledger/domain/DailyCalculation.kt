package dz.dailyledger.domain

/** Monetary amounts are whole DZD; checked arithmetic prevents silent overflow. */
data class DailyCalculation(
    val supplierTotal: Long,
    val theoreticalFinal: Long,
    val actualFinal: Long,
    /** Actual minus theoretical. Positive means actual is higher. */
    val variance: Long,
)

object DailyCalculator {
    const val DEFAULT_FLOAT_DZD = 5_000L

    fun calculate(
        g1: Long,
        g2: Long,
        j1: Long,
        j2: Long,
        suppliers: List<Long>,
        actualCash: Long,
        startingFloat: Long = DEFAULT_FLOAT_DZD,
    ): DailyCalculation {
        require(listOf(g1, g2, j1, j2, actualCash, startingFloat).all { it >= 0 })
        require(suppliers.all { it >= 0 })

        val supplierTotal = suppliers.fold(0L) { total, amount -> Math.addExact(total, amount) }
        // CT = G1 - G2 - J1 - J2 - (LV1 + ... + LVn)
        val theoretical = Math.subtractExact(
            Math.subtractExact(
                Math.subtractExact(Math.subtractExact(g1, g2), j1),
                j2,
            ),
            supplierTotal,
        )
        // CC = C - K - J1 - J2 - (LV1 + ... + LVn)
        val actual = Math.subtractExact(
            Math.subtractExact(
                Math.subtractExact(Math.subtractExact(actualCash, startingFloat), j1),
                j2,
            ),
            supplierTotal,
        )

        return DailyCalculation(
            supplierTotal = supplierTotal,
            theoreticalFinal = theoretical,
            actualFinal = actual,
            variance = Math.subtractExact(actual, theoretical),
        )
    }
}
