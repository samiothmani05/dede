# Daily Ledger (دفتر المتجر)

An offline Android app for entering a store's daily shift revenues, worker payouts, supplier payments, notes, and register count. The interface has English fallback strings and Arabic translations; Android's Arabic locale switches the layout to RTL. All monetary entries are whole Algerian dinars (DZD).

## Formula choices

The supplied formula for CT uses `G2`, although the input list only names `G1`. This implementation treats **G2 as second-half revenue** and includes a required input for it. The daily screen date is the device's current local calendar date. Saving again on the same date updates that day's report. The displayed signed difference is **CC − CT** (actual minus theoretical); positive means the actual result is higher.

```text
SupplierTotal = LV1 + ... + LVn
CT = G1 - G2 - J1 - J2 - SupplierTotal
CC = C - K - J1 - J2 - SupplierTotal
Difference = CC - CT
K = 5,000 DZD (fixed)
```

Blank worker or supplier amounts are treated as zero. G1, G2, and C are required. Negative and fractional values are rejected; inputs are whole DZD. Arithmetic uses checked 64-bit integer operations, so overflow is surfaced instead of silently changing a total. Arabic-Indic and Persian digits are accepted.

## Project layout

```text
app/src/main/kotlin/dz/dailyledger/
  data/       Room entities/DAO/repository and encrypted database setup
  domain/     Pure cash-flow calculation logic
  ui/         Compose screens and ViewModel state
  MainActivity.kt
  LedgerApplication.kt
app/src/main/res/values/       English strings and Android theme
app/src/main/res/values-ar/    Arabic strings
```

Room stores one report row per calendar date and a separate ordered row for every supplier payment. Saving the parent and supplier rows is one database transaction. The history list is ordered newest first; tapping a report opens its full inputs, result, notes, and save time.

## Local data protection

The database is encrypted with SQLCipher. Its random passphrase is wrapped by an AES-GCM key stored in Android Keystore. The app requests no network access and disables Android backup because restoring an encrypted database without its device key would be unusable. Reports stay on this device; clearing app data or uninstalling removes both the database and the key. Add an explicit encrypted export/import flow before relying on this as the only copy of business records across device replacement.

## Build an APK

1. If you have Gradle 8.13 installed but no Gradle wrapper, run `gradle wrapper --gradle-version 8.13` from this folder. (The wrapper bootstrap JAR is not bundled.)
2. Open this `DailyLedger` folder in Android Studio.
3. Use JDK 17 and install Android SDK Platform 36 when prompted, then let Gradle sync.
4. For a local debug install, choose **Build > Build APK(s)**. For a release APK, choose **Build > Generate Signed Bundle / APK** and sign it with a release key you control.

The module uses Android Gradle Plugin 8.13.2, Gradle 8.13, Kotlin 2.2.21, Compose BOM 2026.09.00, Room 2.8.5, and SQLCipher for Android 4.19.1. The release build enables R8 and resource shrinking. A generated, signed APK is not included in this source package.

## Operational notes

- Reports use the phone's current time zone to determine the day and save the exact epoch-millisecond save time.
- There is one report per date; saving again replaces that date's report and supplier rows atomically.
- The daily form opens today's report when one already exists. Past reports are view-only in History.
- Before distributing, set the final application ID, review current store publishing requirements, and validate the signed release on representative Android devices and locale/RTL configurations.
